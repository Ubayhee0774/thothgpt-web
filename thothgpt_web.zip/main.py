from flask import Flask, request, render_template
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import datetime

app = Flask(__name__)

# Setup Google Sheets
SHEET_ID = "ID_SPREADSHEET_MU"
WORKSHEET_NAME = "unanswered_questions"
SCOPE = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
CREDS = ServiceAccountCredentials.from_json_keyfile_name("client_secret.json", SCOPE)
gc = gspread.authorize(CREDS)
sheet = gc.open_by_key(SHEET_ID)
wks = sheet.worksheet(WORKSHEET_NAME)
if wks.cell(1, 1).value == "":
    wks.update("A1", [["question", "timestamp"]])

# Dummy QnA dataset
questions = [
    "Apa itu CE-LVD?",
    "Bagaimana proses audit CE-RED?",
    "Kapan aturan CE-RoHS diperbarui?"
]
answers = [
    "CE-LVD adalah sertifikasi kelistrikan tegangan rendah.",
    "Audit CE-RED dilakukan untuk memastikan perangkat wireless aman.",
    "CE-RoHS terakhir diperbarui tahun 2021."
]

vectorizer = TfidfVectorizer().fit(questions)
X = vectorizer.transform(questions)

@app.route("/", methods=["GET", "POST"])
def index():
    answer = None
    if request.method == "POST":
        question = request.form["question"]
        q_vec = vectorizer.transform([question])
        scores = cosine_similarity(q_vec, X)[0]
        top_indices = scores.argsort()[::-1][:3]
        top_answers = [f"{questions[i]} ➜ {answers[i]}" for i in top_indices if scores[i] > 0.3]
        if top_answers:
            answer = "<br><br>".join(top_answers)
        else:
            now = datetime.datetime.now().isoformat()
            wks.append_row([question, now])
            answer = "❌ Maaf, belum ada jawaban. Pertanyaanmu sudah kami catat."
    return render_template("index.html", answer=answer)

if __name__ == "__main__":
    app.run(debug=True)